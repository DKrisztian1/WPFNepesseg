﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp6.Model;
using System.IO;


namespace WpfApp6
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Telepules> telepulesek = new List<Telepules>();
        List<Telepules> ujTelepulesek = new List<Telepules>();
        List<string> DISTmegyek = new List<string>();
        
        
        public MainWindow()
        {
            InitializeComponent();
            StreamReader sr = new StreamReader("Data\\kozerdeku_lakossag_2022.csv");
            sr.ReadLine();
            while (!sr.EndOfStream)
            {
                string sor = sr.ReadLine();
                string[] mezok = sor.Split(';');
                Telepules ujtelepules = new Telepules(mezok[2], mezok[3], mezok[4], int.Parse(mezok[5].Replace(" ", "")), int.Parse(mezok[6].Replace(" ", "")));
                telepulesek.Add(ujtelepules);

                if (!DISTmegyek.Contains(mezok[2]))
                {
                    DISTmegyek.Add(mezok[2]);
                    cbMegyek.Items.Add(mezok[2]);
                }
            }
            sr.Close();
            dgTelepulesek.ItemsSource = telepulesek;
        }

        private void cbMegyek_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            StreamReader sr = new StreamReader("Data\\kozerdeku_lakossag_2022.csv");
            sr.ReadLine();
            while (!sr.EndOfStream)
            {
                string sor = sr.ReadLine();
                string[] mezok = sor.Split(';');
                Telepules ujabbtelepules = new Telepules(mezok[2], mezok[3], mezok[4], int.Parse(mezok[5].Replace(" ", "")), int.Parse(mezok[6].Replace(" ", "")));
                if (mezok[2] == cbMegyek.SelectedItem)
                {
                    ujTelepulesek.Add(ujabbtelepules);
                }
            }
            sr.Close();
            dgTelepulesek.ItemsSource = ujTelepulesek;
        }
    }
}
